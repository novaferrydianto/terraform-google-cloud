## update repo centos7
yum update -y

